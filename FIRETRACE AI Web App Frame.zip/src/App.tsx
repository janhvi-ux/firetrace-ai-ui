import { useState, useRef, useEffect } from "react";

// ─── Data ────────────────────────────────────────────────────────────────────

const HOTSPOTS = [
  { id: "D001", label: "VKI Area, Road No. 9",    x: 38, y: 42, risk: 4 },
  { id: "D002", label: "Sitapura Industrial Zone", x: 62, y: 66, risk: 2 },
  { id: "D003", label: "22 Godam Area",            x: 26, y: 56, risk: 3 },
  { id: "D004", label: "Mansarovar Industrial",    x: 53, y: 29, risk: 2 },
];

const FILTER_CHIPS = ["VKI Area", "Sitapura", "22 Godam"];

const EXPOSURES = [
  { icon: "🏭", name: "Apex Chemicals Facility",  dist: "Epicenter",   sev: "critical" },
  { icon: "⛽", name: "Petrol Pump",               dist: "800 m away",  sev: "high"     },
  { icon: "🧪", name: "Chemical Storage",          dist: "1.2 km away", sev: "high"     },
  { icon: "🏫", name: "Vidya Mandir School",       dist: "1.8 km away", sev: "moderate" },
  { icon: "🏘️", name: "Residential Cluster B-4",  dist: "2.3 km away", sev: "moderate" },
];

// ─── Primitives ───────────────────────────────────────────────────────────────

function FlameIcon({ size = 20 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path
        d="M12 2C12 2 8 6 8 10C8 10 6.5 9 6 7.5C6 7.5 3 11 3 14.5C3 18.5 7 22 12 22C17 22 21 18.5 21 14.5C21 11 18.5 8 18.5 8C18.5 8 17.5 10.5 16 11C16 11 16 7 12 2Z"
        fill="#EF4444"
      />
      <path
        d="M12 14C12 14 10 15.5 10 17C10 18.1 10.9 19 12 19C13.1 19 14 18.1 14 17C14 15.5 12 14 12 14Z"
        fill="#F59E0B"
      />
    </svg>
  );
}

function Divider() {
  return <div style={{ height: "1px", background: "#F1F5F9", margin: "0 18px" }} />;
}

// ─── Map ──────────────────────────────────────────────────────────────────────

function JaipurMap({
  selectedId,
  onSelect,
}: {
  selectedId: string | null;
  onSelect: (id: string) => void;
}) {
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        background: "#E9EDF0",
        borderRadius: "12px",
        overflow: "hidden",
        position: "relative",
      }}
    >
      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="xMidYMid slice"
        width="100%"
        height="100%"
        style={{ position: "absolute", inset: 0 }}
      >
        <rect width="100" height="100" fill="#E9EDF0" />

        {/* Terrain patches */}
        <ellipse cx="14" cy="19" rx="13" ry="8"  fill="#D1FAE5" opacity="0.55" />
        <ellipse cx="81" cy="14" rx="11" ry="7"  fill="#BBF7D0" opacity="0.5"  />
        <ellipse cx="76" cy="80" rx="14" ry="8"  fill="#D1FAE5" opacity="0.5"  />
        <ellipse cx="10" cy="76" rx="8"  rx2="10" ry="10" fill="#BBF7D0" opacity="0.4" />
        <ellipse cx="50" cy="91" rx="17" ry="6"  fill="#D1FAE5" opacity="0.38" />

        {/* Aravalli ridge */}
        <path d="M0,34 Q9,27 17,31 Q25,35 21,43 Q16,49 8,45 Q0,41 0,34Z" fill="#D4DBDF" opacity="0.45" />
        <path d="M85,24 Q93,19 100,21 L100,34 Q95,32 88,29Z"               fill="#D4DBDF" opacity="0.38" />

        {/* Dravyavati River */}
        <path d="M4,48 Q12,44 18,50 Q27,58 35,54 Q43,50 49,56 Q56,62 63,58 Q71,54 77,60 Q83,66 91,62 Q96,59 100,60"
              fill="none" stroke="#BAE6FD" strokeWidth="3"   opacity="0.8" />
        <path d="M4,50 Q12,46 18,52 Q27,60 35,56 Q43,52 49,58 Q56,64 63,60 Q71,56 77,62 Q83,68 91,64 Q96,61 100,62"
              fill="none" stroke="#BAE6FD" strokeWidth="1.5" opacity="0.45" />

        {/* Reservoirs */}
        <ellipse cx="22" cy="72" rx="5" ry="3" fill="#BAE6FD" opacity="0.65" />
        <ellipse cx="71" cy="35" rx="4" ry="2.5" fill="#BAE6FD" opacity="0.55" />

        {/* Major road grid */}
        <line x1="0"   y1="25" x2="100" y2="25" stroke="#CBD5E1" strokeWidth="1.2" opacity="0.7" />
        <line x1="0"   y1="42" x2="100" y2="42" stroke="#B8C5D4" strokeWidth="1.7" opacity="0.85" />
        <line x1="0"   y1="60" x2="100" y2="60" stroke="#CBD5E1" strokeWidth="1.2" opacity="0.7" />
        <line x1="0"   y1="78" x2="100" y2="78" stroke="#CBD5E1" strokeWidth="1"   opacity="0.6" />
        <line x1="20"  y1="0"  x2="20"  y2="100" stroke="#CBD5E1" strokeWidth="1.2" opacity="0.7" />
        <line x1="38"  y1="0"  x2="38"  y2="100" stroke="#B8C5D4" strokeWidth="1.7" opacity="0.85" />
        <line x1="58"  y1="0"  x2="58"  y2="100" stroke="#CBD5E1" strokeWidth="1.2" opacity="0.7" />
        <line x1="78"  y1="0"  x2="78"  y2="100" stroke="#CBD5E1" strokeWidth="1"   opacity="0.6" />

        {/* Diagonal links */}
        <path d="M5,60 Q15,55 20,60 Q30,68 38,65"  fill="none" stroke="#CBD5E1" strokeWidth="0.8" opacity="0.5" />
        <path d="M58,30 Q65,22 76,20 Q86,18 91,25"  fill="none" stroke="#CBD5E1" strokeWidth="0.8" opacity="0.5" />

        {/* Industrial zone blocks */}
        {[
          [31,36],[34,36],[37,36],[31,40],[34,40],[37,40],[31,44],[34,44],
          [56,63],[59,63],[62,63],[56,67],[59,67],[62,67],
          [21,49],[24,49],[27,49],[21,53],[24,53],[27,53],[21,57],[24,57],
          [45,23],[48,23],[51,23],[45,27],[48,27],[51,27],[45,31],[48,31],
        ].map(([bx, by], i) => (
          <rect key={i} x={bx} y={by} width="2.2" height="2.2" fill="#C8D4E0" rx="0.3" opacity="0.9" />
        ))}

        {/* Road labels */}
        <text x="3"  y="41" fontSize="1.6" fill="#94A3B8" fontFamily="Inter,sans-serif" fontWeight="500">Road No. 9</text>
        <text x="3"  y="59" fontSize="1.6" fill="#94A3B8" fontFamily="Inter,sans-serif" fontWeight="500">Sitapura Rd</text>
        <text x="39" y="9"  fontSize="1.6" fill="#94A3B8" fontFamily="Inter,sans-serif" fontWeight="500"
              transform="rotate(90,39,9) translate(0,-0.5)">JLN Marg</text>

        {/* Pins */}
        {HOTSPOTS.map((h) => {
          const active = selectedId === h.id;
          return (
            <g
              key={h.id}
              transform={`translate(${h.x}, ${h.y})`}
              style={{ cursor: "pointer" }}
              onClick={() => onSelect(h.id)}
            >
              {active && (
                <>
                  <circle r="26" fill="#F59E0B" opacity="0.10" className="pulse-ring" />
                  <circle r="18" fill="#F59E0B" opacity="0.18" className="pulse-ring" style={{ animationDelay: "0.3s" }} />
                  <circle r="12" fill="#F59E0B" opacity="0.22" />
                </>
              )}
              <circle
                r="5.5"
                fill="#EF4444"
                stroke="white"
                strokeWidth="2"
                opacity={active ? 1 : 0.6}
                className={active ? "pin-activate" : ""}
                style={{ transition: "opacity 0.25s ease" }}
              />
              {/* Callout — D001 only */}
              {active && h.id === "D001" && (
                <foreignObject x="9" y="-22" width="158" height="34">
                  <div
                    style={{
                      background: "#0F172A",
                      color: "white",
                      fontSize: "11px",
                      fontWeight: 600,
                      padding: "5px 10px",
                      borderRadius: "6px",
                      whiteSpace: "nowrap",
                      fontFamily: "Inter,sans-serif",
                      boxShadow: "0 4px 14px rgba(0,0,0,0.28)",
                      display: "inline-flex",
                      alignItems: "center",
                      gap: "5px",
                    }}
                  >
                    <span style={{ color: "#F59E0B" }}>◉</span> Selected: Hotspot #D001
                  </div>
                </foreignObject>
              )}
            </g>
          );
        })}
      </svg>

      {/* Legend */}
      <div
        style={{
          position: "absolute",
          top: "12px",
          left: "50%",
          transform: "translateX(-50%)",
          background: "rgba(255,255,255,0.92)",
          backdropFilter: "blur(6px)",
          border: "1px solid #E2E8F0",
          borderRadius: "8px",
          padding: "6px 14px",
          display: "flex",
          gap: "18px",
          boxShadow: "0 2px 8px rgba(0,0,0,0.07)",
          zIndex: 5,
        }}
      >
        {[
          { dot: "#EF4444", label: "High Risk (Level 4–5)" },
          { dot: "#F59E0B", label: "Moderate Risk (Level 2–3)" },
          { dot: "#22C55E", label: "Monitored (Clear)"         },
        ].map(({ dot, label }) => (
          <div key={label} style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <div style={{ width: "9px", height: "9px", borderRadius: "50%", background: dot }} />
            <span style={{ fontSize: "11.5px", fontWeight: 500, color: "#334155" }}>{label}</span>
          </div>
        ))}
      </div>

      {/* Compass */}
      <div
        style={{
          position: "absolute",
          bottom: "16px",
          right: "16px",
          background: "rgba(255,255,255,0.88)",
          backdropFilter: "blur(4px)",
          border: "1px solid #E2E8F0",
          borderRadius: "8px",
          padding: "7px",
        }}
      >
        <svg width="30" height="30" viewBox="0 0 32 32">
          <circle cx="16" cy="16" r="14" fill="white" stroke="#E2E8F0" strokeWidth="1" />
          <polygon points="16,4 14,16 18,16"  fill="#EF4444" />
          <polygon points="16,28 14,16 18,16" fill="#94A3B8" />
          <polygon points="4,16 16,14 16,18"  fill="#94A3B8" />
          <polygon points="28,16 16,14 16,18" fill="#94A3B8" />
          <circle cx="16" cy="16" r="2" fill="#0F172A" />
          <text x="16" y="3.2" fontSize="4" fill="#EF4444" textAnchor="middle" fontWeight="700" fontFamily="Inter">N</text>
        </svg>
      </div>

      {/* Scale */}
      <div
        style={{
          position: "absolute",
          bottom: "16px",
          left: "16px",
          background: "rgba(255,255,255,0.88)",
          backdropFilter: "blur(4px)",
          border: "1px solid #E2E8F0",
          borderRadius: "6px",
          padding: "5px 10px",
          display: "flex",
          alignItems: "center",
          gap: "8px",
        }}
      >
        <div style={{ position: "relative", width: "48px", height: "3px", background: "#475569" }}>
          <div style={{ position: "absolute", left: 0,  top: "-3px", width: "1px", height: "9px", background: "#475569" }} />
          <div style={{ position: "absolute", right: 0, top: "-3px", width: "1px", height: "9px", background: "#475569" }} />
        </div>
        <span style={{ fontSize: "11px", color: "#334155", fontWeight: 500 }}>2 km</span>
      </div>

      {/* Region badge */}
      <div
        style={{
          position: "absolute",
          top: "12px",
          right: "16px",
          background: "rgba(255,255,255,0.8)",
          border: "1px solid #E2E8F0",
          borderRadius: "5px",
          padding: "3px 8px",
          fontSize: "10.5px",
          fontWeight: 500,
          color: "#64748B",
        }}
      >
        Jaipur Industrial Zone, Rajasthan
      </div>
    </div>
  );
}

// ─── Sidebar States ───────────────────────────────────────────────────────────

function SidebarEmpty() {
  return (
    <div
      style={{
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "32px 24px",
        textAlign: "center",
        gap: "16px",
      }}
    >
      {/* Idle illustration */}
      <div
        style={{
          width: "72px",
          height: "72px",
          borderRadius: "18px",
          background: "linear-gradient(135deg, #F1F5F9 0%, #E2E8F0 100%)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginBottom: "4px",
        }}
      >
        <svg width="34" height="34" viewBox="0 0 24 24" fill="none">
          <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7z"
                fill="#CBD5E1" />
          <circle cx="12" cy="9" r="2.5" fill="#94A3B8" />
        </svg>
      </div>

      <div>
        <div style={{ fontSize: "15px", fontWeight: 700, color: "#0F172A", marginBottom: "8px" }}>
          No Hotspot Selected
        </div>
        <div style={{ fontSize: "13px", color: "#64748B", lineHeight: 1.6, maxWidth: "220px", margin: "0 auto" }}>
          Select a hotspot on the map to run AI classification and buffer check.
        </div>
      </div>

      {/* Idle stats row */}
      <div
        style={{
          display: "flex",
          gap: "0",
          width: "100%",
          marginTop: "8px",
          border: "1px solid #E2E8F0",
          borderRadius: "10px",
          overflow: "hidden",
        }}
      >
        {[
          { label: "Active Zones",    value: "4",    color: "#EF4444" },
          { label: "Monitored",       value: "18",   color: "#22C55E" },
          { label: "Alerts Today",    value: "2",    color: "#F59E0B" },
        ].map(({ label, value, color }, i) => (
          <div
            key={label}
            style={{
              flex: 1,
              padding: "12px 8px",
              textAlign: "center",
              borderRight: i < 2 ? "1px solid #E2E8F0" : "none",
              background: "white",
            }}
          >
            <div style={{ fontSize: "20px", fontWeight: 800, color, letterSpacing: "-0.5px" }}>{value}</div>
            <div style={{ fontSize: "10.5px", color: "#94A3B8", fontWeight: 500, marginTop: "2px" }}>{label}</div>
          </div>
        ))}
      </div>

      {/* Recent activity */}
      <div style={{ width: "100%", marginTop: "4px" }}>
        <div style={{ fontSize: "10.5px", fontWeight: 600, color: "#94A3B8", letterSpacing: "0.7px", textTransform: "uppercase", marginBottom: "8px", textAlign: "left" }}>
          Recent Activity
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          {[
            { time: "08:41 AM", text: "Thermal spike at VKI Area, Road No. 9", dot: "#EF4444" },
            { time: "07:15 AM", text: "Level 2 alert cleared at Mansarovar", dot: "#22C55E" },
            { time: "06:30 AM", text: "Sitapura patrol report filed", dot: "#64748B" },
          ].map(({ time, text, dot }) => (
            <div
              key={time}
              style={{
                display: "flex",
                alignItems: "flex-start",
                gap: "9px",
                padding: "9px 10px",
                background: "white",
                borderRadius: "7px",
                border: "1px solid #F1F5F9",
                textAlign: "left",
              }}
            >
              <div style={{ width: "7px", height: "7px", borderRadius: "50%", background: dot, marginTop: "3px", flexShrink: 0 }} />
              <div>
                <div style={{ fontSize: "12px", color: "#334155", fontWeight: 500, lineHeight: 1.4 }}>{text}</div>
                <div style={{ fontSize: "10.5px", color: "#94A3B8", marginTop: "2px" }}>{time}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function SidebarActive({
  onDispatch,
  dispatched,
}: {
  onDispatch: () => void;
  dispatched: boolean;
}) {
  return (
    <>
      <div style={{ flex: 1, overflowY: "auto", padding: "16px 18px", display: "flex", flexDirection: "column", gap: "11px" }}>

        {/* Card 1: Hotspot ID */}
        <div style={{ padding: "14px", background: "#F8FAFC", borderRadius: "10px", border: "1px solid #E2E8F0" }}>
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "10px" }}>
            <div style={{ flex: 1 }}>
              <span
                style={{
                  fontSize: "10.5px",
                  fontWeight: 700,
                  color: "#EF4444",
                  background: "#FEF2F2",
                  padding: "2px 7px",
                  borderRadius: "4px",
                  letterSpacing: "0.5px",
                  display: "inline-block",
                  marginBottom: "7px",
                }}
              >
                HOTSPOT #D001
              </span>
              <div style={{ fontSize: "15px", fontWeight: 700, color: "#0F172A", lineHeight: 1.3 }}>
                VKI Industrial Area, Jaipur
              </div>
              <div style={{ fontSize: "12px", color: "#64748B", marginTop: "3px" }}>
                VKI Area, Road No. 9 · Rajasthan
              </div>
            </div>
            <div
              style={{
                width: "36px", height: "36px", borderRadius: "8px",
                background: "#FEF2F2",
                display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
              }}
            >
              <FlameIcon size={20} />
            </div>
          </div>
          <div style={{ display: "flex", gap: "0", marginTop: "12px", paddingTop: "12px", borderTop: "1px solid #E2E8F0" }}>
            {[
              { label: "Detected",  value: "08:41 AM" },
              { label: "Duration",  value: "2h 18m"   },
              { label: "Zone Type", value: "Industrial" },
            ].map(({ label, value }, i) => (
              <div key={label} style={{ flex: 1, paddingLeft: i > 0 ? "12px" : 0, borderLeft: i > 0 ? "1px solid #E2E8F0" : "none" }}>
                <div style={{ fontSize: "10px", color: "#94A3B8", fontWeight: 500 }}>{label}</div>
                <div style={{ fontSize: "12.5px", color: "#334155", fontWeight: 600, marginTop: "2px" }}>{value}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Card 2: AI Classification */}
        <div style={{ padding: "14px", background: "#FFFBEB", borderRadius: "10px", border: "1px solid #FDE68A" }}>
          <div style={{ fontSize: "10px", fontWeight: 600, color: "#92400E", letterSpacing: "0.7px", textTransform: "uppercase", marginBottom: "9px" }}>
            AI Classification
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "10px" }}>
            <div>
              <div style={{ fontSize: "14.5px", fontWeight: 700, color: "#0F172A" }}>Industrial Chemical Flare</div>
              <div style={{ fontSize: "11.5px", color: "#64748B", marginTop: "3px" }}>Hydrocarbon + VOC compound signature</div>
            </div>
            <div
              style={{
                padding: "5px 11px",
                background: "#F59E0B",
                borderRadius: "6px",
                fontSize: "13px",
                fontWeight: 800,
                color: "white",
                whiteSpace: "nowrap",
                boxShadow: "0 2px 8px rgba(245,158,11,0.32)",
                flexShrink: 0,
              }}
            >
              94% Confidence
            </div>
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "5px", marginTop: "10px" }}>
            {["Chemical", "Toxic Fumes", "SE Wind Drift", "Night Onset"].map((tag) => (
              <span
                key={tag}
                style={{
                  fontSize: "10.5px", fontWeight: 500, color: "#92400E",
                  background: "rgba(245,158,11,0.14)", padding: "3px 8px", borderRadius: "4px",
                }}
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Card 3: Risk Level */}
        <div style={{ padding: "14px", background: "#EF4444", borderRadius: "10px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <div>
              <div style={{ fontSize: "10px", fontWeight: 600, color: "rgba(255,255,255,0.65)", letterSpacing: "0.7px", textTransform: "uppercase" }}>
                Risk Assessment
              </div>
              <div style={{ fontSize: "24px", fontWeight: 800, color: "white", letterSpacing: "-0.5px", marginTop: "3px" }}>
                Level 4 / 5
              </div>
              <div style={{ fontSize: "12.5px", fontWeight: 600, color: "rgba(255,255,255,0.85)", marginTop: "1px" }}>
                High Risk · Immediate Action Required
              </div>
            </div>
            <div style={{ fontSize: "28px" }}>⚠️</div>
          </div>
          <div style={{ display: "flex", gap: "5px", marginTop: "12px" }}>
            {[1, 2, 3, 4, 5].map((l) => (
              <div
                key={l}
                style={{
                  flex: 1, height: "5px", borderRadius: "3px",
                  background: l <= 4 ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.22)",
                }}
              />
            ))}
          </div>
        </div>

        {/* Card 4: Exposed Assets */}
        <div style={{ padding: "14px", background: "#F8FAFC", borderRadius: "10px", border: "1px solid #E2E8F0" }}>
          <div style={{ fontSize: "10px", fontWeight: 600, color: "#64748B", letterSpacing: "0.7px", textTransform: "uppercase", marginBottom: "10px" }}>
            Nearby Exposure
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: "7px" }}>
            {EXPOSURES.map(({ icon, name, dist, sev }) => (
              <div
                key={name}
                style={{
                  display: "flex", alignItems: "center", gap: "9px",
                  padding: "8px 10px",
                  borderRadius: "7px",
                  background: "white",
                  border: `1px solid ${sev === "critical" ? "#FECACA" : sev === "high" ? "#FEF3C7" : "#E2E8F0"}`,
                }}
              >
                <span style={{ fontSize: "15px", flexShrink: 0 }}>{icon}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: "12px", fontWeight: 600, color: "#0F172A", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                    {name}
                  </div>
                  <div style={{ fontSize: "10.5px", color: "#94A3B8", marginTop: "1px" }}>{dist}</div>
                </div>
                <div
                  style={{
                    width: "7px", height: "7px", borderRadius: "50%", flexShrink: 0,
                    background: sev === "critical" ? "#EF4444" : sev === "high" ? "#F59E0B" : "#94A3B8",
                  }}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Weather strip */}
        <div style={{ padding: "12px 14px", background: "#F8FAFC", borderRadius: "10px", border: "1px solid #E2E8F0" }}>
          <div style={{ fontSize: "10px", fontWeight: 600, color: "#64748B", letterSpacing: "0.7px", textTransform: "uppercase", marginBottom: "10px" }}>
            Spread Conditions
          </div>
          <div style={{ display: "flex", gap: "8px" }}>
            {[
              { label: "Wind",     value: "18 km/h", sub: "SE direction" },
              { label: "Temp.",    value: "34°C",    sub: "Ambient"      },
              { label: "Humidity", value: "22%",     sub: "Low — dry"    },
            ].map(({ label, value, sub }) => (
              <div
                key={label}
                style={{
                  flex: 1, background: "white", border: "1px solid #E2E8F0",
                  borderRadius: "7px", padding: "9px 6px", textAlign: "center",
                }}
              >
                <div style={{ fontSize: "9.5px", color: "#94A3B8", fontWeight: 500 }}>{label}</div>
                <div style={{ fontSize: "14px", fontWeight: 700, color: "#0F172A", marginTop: "2px" }}>{value}</div>
                <div style={{ fontSize: "9.5px", color: "#64748B", marginTop: "1px" }}>{sub}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Action buttons */}
      <div style={{ padding: "14px 18px", borderTop: "1px solid #F1F5F9", display: "flex", flexDirection: "column", gap: "8px" }}>
        <button
          onClick={onDispatch}
          style={{
            width: "100%",
            padding: "13px",
            background: dispatched ? "#22C55E" : "#EF4444",
            color: "white",
            border: "none",
            borderRadius: "8px",
            fontSize: "13.5px",
            fontWeight: 700,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "7px",
            fontFamily: "'Inter',sans-serif",
            boxShadow: dispatched ? "0 4px 14px rgba(34,197,94,0.38)" : "0 4px 14px rgba(239,68,68,0.32)",
            transition: "background 0.25s ease, box-shadow 0.25s ease",
            letterSpacing: "0.1px",
          }}
          onMouseEnter={(e) => {
            if (!dispatched) e.currentTarget.style.background = "#DC2626";
          }}
          onMouseLeave={(e) => {
            if (!dispatched) e.currentTarget.style.background = "#EF4444";
          }}
        >
          {dispatched ? "✓  Alert Dispatched" : "🚨  Dispatch Emergency Alert"}
        </button>
        <button
          style={{
            width: "100%",
            padding: "11px",
            background: "white",
            color: "#334155",
            border: "1.5px solid #E2E8F0",
            borderRadius: "8px",
            fontSize: "13px",
            fontWeight: 600,
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: "7px",
            fontFamily: "'Inter',sans-serif",
            transition: "background 0.15s ease",
          }}
          onMouseEnter={(e) => (e.currentTarget.style.background = "#F8FAFC")}
          onMouseLeave={(e) => (e.currentTarget.style.background = "white")}
        >
          📄  Export Incident Report
        </button>
      </div>
    </>
  );
}

// ─── Toast ────────────────────────────────────────────────────────────────────

function DispatchToast({ visible }: { visible: boolean }) {
  if (!visible) return null;
  return (
    <div
      style={{
        position: "fixed",
        bottom: "32px",
        left: "50%",
        transform: "translateX(-50%)",
        background: "#0F172A",
        color: "white",
        padding: "14px 22px",
        borderRadius: "10px",
        fontSize: "13.5px",
        fontWeight: 600,
        display: "flex",
        alignItems: "center",
        gap: "10px",
        boxShadow: "0 8px 32px rgba(0,0,0,0.22)",
        zIndex: 200,
        animation: "fadeSlideUp 0.25s ease",
        whiteSpace: "nowrap",
      }}
    >
      <div
        style={{
          width: "24px", height: "24px", borderRadius: "50%",
          background: "#22C55E",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: "13px", fontWeight: 800,
        }}
      >
        ✓
      </div>
      Emergency alert dispatched — Hotspot #D001 · VKI Industrial Area, Jaipur
      <div
        style={{
          marginLeft: "6px",
          padding: "2px 8px",
          background: "rgba(255,255,255,0.12)",
          borderRadius: "4px",
          fontSize: "11px",
          color: "rgba(255,255,255,0.65)",
        }}
      >
        11:03 AM
      </div>
    </div>
  );
}

// ─── Screen label ─────────────────────────────────────────────────────────────

function ScreenBadge({ screen }: { screen: 1 | 2 }) {
  const [animKey, setAnimKey] = useState(0);
  const prev = useRef(screen);

  useEffect(() => {
    if (prev.current !== screen) {
      setAnimKey((k) => k + 1);
      prev.current = screen;
    }
  }, [screen]);

  return (
    <div
      key={animKey}
      className="badge-enter"
      style={{
        position: "absolute",
        top: "88px",
        left: "50%",
        transform: "translateX(-50%)",
        background: screen === 1 ? "rgba(100,116,139,0.9)" : "rgba(239,68,68,0.9)",
        color: "white",
        fontSize: "11px",
        fontWeight: 700,
        padding: "4px 14px",
        borderRadius: "20px",
        letterSpacing: "0.6px",
        zIndex: 20,
        backdropFilter: "blur(6px)",
        pointerEvents: "none",
        textTransform: "uppercase",
        display: "flex",
        alignItems: "center",
        gap: "7px",
        boxShadow: screen === 2 ? "0 2px 12px rgba(239,68,68,0.3)" : "0 2px 8px rgba(0,0,0,0.12)",
        transition: "background 0.3s ease, box-shadow 0.3s ease",
      }}
    >
      <span
        style={{
          width: "6px",
          height: "6px",
          borderRadius: "50%",
          background: "rgba(255,255,255,0.8)",
          display: "inline-block",
          ...(screen === 2 ? { animation: "blink 1.4s ease-in-out infinite" } : {}),
        }}
      />
      {screen === 1 ? "Screen 1 — Default State" : "Screen 2 — Hotspot Selected"}
      <span style={{ opacity: 0.55, fontWeight: 400, letterSpacing: 0 }}>
        {screen === 1 ? "· Click a pin to continue →" : "· Alert mode active"}
      </span>
    </div>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [selectedId, setSelectedId]   = useState<string | null>(null);
  const [dispatched, setDispatched]   = useState(false);
  const [showToast, setShowToast]     = useState(false);
  const [activeFilters, setActiveFilters] = useState<string[]>([]);
  const [mapFlash, setMapFlash]       = useState(false);

  function handleSelect(id: string) {
    setSelectedId((prev) => (prev === id ? null : id));
    setDispatched(false);
    setShowToast(false);
    setMapFlash(true);
    setTimeout(() => setMapFlash(false), 320);
  }

  function handleDispatch() {
    setDispatched(true);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 4000);
  }

  function toggleFilter(chip: string) {
    setActiveFilters((prev) =>
      prev.includes(chip) ? prev.filter((c) => c !== chip) : [...prev, chip]
    );
  }

  const screen: 1 | 2 = selectedId ? 2 : 1;

  return (
    <div
      style={{
        width: "1440px",
        height: "900px",
        display: "flex",
        flexDirection: "column",
        background: "#F8FAFC",
        fontFamily: "'Inter', system-ui, sans-serif",
        overflow: "hidden",
        position: "relative",
      }}
    >
      {/* ── HEADER ── */}
      <header
        style={{
          height: "72px",
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 24px",
          background: "#FFFFFF",
          borderBottom: "1px solid #E2E8F0",
          zIndex: 10,
        }}
      >
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px", minWidth: "272px" }}>
          <div
            style={{
              width: "38px", height: "38px",
              background: "linear-gradient(135deg, #EF4444 0%, #F97316 100%)",
              borderRadius: "10px",
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 2px 8px rgba(239,68,68,0.28)",
            }}
          >
            <FlameIcon size={22} />
          </div>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: "5px" }}>
              <span style={{ fontSize: "18px", fontWeight: 800, color: "#0F172A", letterSpacing: "-0.5px" }}>
                FIRETRACE
              </span>
              <span
                style={{
                  fontSize: "11px", fontWeight: 700, color: "#EF4444",
                  background: "#FEF2F2", padding: "1px 5px", borderRadius: "4px", letterSpacing: "0.5px",
                }}
              >
                AI
              </span>
            </div>
            <div style={{ fontSize: "11px", color: "#64748B", marginTop: "1px" }}>
              अग्नेः पूर्वचेतना, राष्ट्रस्य सुरक्षा।
            </div>
          </div>
        </div>

        {/* Search + chips */}
        <div style={{ display: "flex", alignItems: "center", gap: "10px", flex: 1, maxWidth: "560px" }}>
          <div style={{ position: "relative", flex: 1 }}>
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none"
                 style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)" }}>
              <circle cx="11" cy="11" r="8" stroke="#94A3B8" strokeWidth="2" />
              <path d="M21 21L16.65 16.65" stroke="#94A3B8" strokeWidth="2" strokeLinecap="round" />
            </svg>
            <input
              type="text"
              placeholder="Search Jaipur industrial zone..."
              style={{
                width: "100%", padding: "9px 14px 9px 34px",
                border: "1.5px solid #E2E8F0", borderRadius: "8px",
                fontSize: "13.5px", color: "#334155", background: "#F8FAFC",
                outline: "none", fontFamily: "'Inter',sans-serif",
              }}
            />
          </div>
          <div style={{ display: "flex", gap: "6px" }}>
            {FILTER_CHIPS.map((chip) => {
              const on = activeFilters.includes(chip);
              return (
                <button
                  key={chip}
                  onClick={() => toggleFilter(chip)}
                  style={{
                    padding: "6px 12px", borderRadius: "20px",
                    fontSize: "12.5px", fontWeight: 600, cursor: "pointer",
                    border: on ? "1.5px solid #EF4444" : "1.5px solid #E2E8F0",
                    background: on ? "#FEF2F2" : "#FFFFFF",
                    color: on ? "#EF4444" : "#64748B",
                    transition: "all 0.15s",
                    fontFamily: "'Inter',sans-serif", whiteSpace: "nowrap",
                  }}
                >
                  {chip}
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Status + User */}
        <div style={{ display: "flex", alignItems: "center", gap: "20px", minWidth: "272px", justifyContent: "flex-end" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <div
              className="status-blink"
              style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#EF4444" }}
            />
            <span style={{ fontSize: "12.5px", fontWeight: 600, color: "#EF4444" }}>4 Active Incidents</span>
          </div>
          <div style={{ width: "1px", height: "24px", background: "#E2E8F0" }} />
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <div
              style={{
                width: "32px", height: "32px", borderRadius: "50%",
                background: "linear-gradient(135deg, #334155, #0F172A)",
                display: "flex", alignItems: "center", justifyContent: "center",
                fontSize: "12px", fontWeight: 700, color: "white",
              }}
            >
              RK
            </div>
            <div>
              <div style={{ fontSize: "12.5px", fontWeight: 600, color: "#0F172A" }}>Rajesh Kumar</div>
              <div style={{ fontSize: "11px", color: "#64748B" }}>Senior Fire Officer</div>
            </div>
          </div>
        </div>
      </header>

      {/* ── MAIN ── */}
      <main
        style={{
          flex: 1, display: "flex", gap: "20px",
          padding: "20px 24px", overflow: "hidden", position: "relative",
        }}
      >
        {/* Map */}
        <div
          style={{
            flex: "0 0 calc(70% - 10px)",
            borderRadius: "12px",
            overflow: "hidden",
            boxShadow: "0 1px 3px rgba(0,0,0,0.07), 0 4px 16px rgba(0,0,0,0.05)",
            position: "relative",
            transition: "box-shadow 0.3s ease",
            ...(selectedId === "D001" ? { boxShadow: "0 1px 3px rgba(0,0,0,0.07), 0 4px 24px rgba(239,68,68,0.14)" } : {}),
          }}
        >
          <JaipurMap selectedId={selectedId} onSelect={handleSelect} />
          {/* Screen transition flash overlay */}
          <div
            style={{
              position: "absolute",
              inset: 0,
              background: "rgba(239,68,68,0.07)",
              borderRadius: "12px",
              pointerEvents: "none",
              opacity: mapFlash ? 1 : 0,
              transition: "opacity 0.32s ease",
            }}
          />
        </div>

        {/* Sidebar */}
        <div
          style={{
            flex: "0 0 calc(30% - 10px)",
            background: "#FFFFFF",
            borderRadius: "12px",
            border: "1px solid #E2E8F0",
            boxShadow: "0 1px 3px rgba(0,0,0,0.05), 0 8px 24px rgba(0,0,0,0.08)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
          }}
        >
          {/* Sidebar header bar */}
          <div
            style={{
              padding: "14px 18px 12px",
              borderBottom: "1px solid #F1F5F9",
              background: "#FAFBFC",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <span style={{ fontSize: "11px", fontWeight: 600, color: "#94A3B8", letterSpacing: "0.8px", textTransform: "uppercase" }}>
              {selectedId ? "Incident Detail" : "Zone Overview"}
            </span>
            <div style={{ display: "flex", gap: "5px" }}>
              {HOTSPOTS.map((h) => (
                <button
                  key={h.id}
                  onClick={() => handleSelect(h.id)}
                  title={h.label}
                  style={{
                    width: "22px", height: "22px", borderRadius: "50%", border: "none",
                    background: selectedId === h.id ? "#EF4444" : "#E2E8F0",
                    cursor: "pointer", fontSize: "8px", fontWeight: 700,
                    color: selectedId === h.id ? "white" : "#64748B",
                    fontFamily: "'Inter',sans-serif",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    transition: "background 0.15s",
                  }}
                >
                  {h.id.replace("D", "")}
                </button>
              ))}
            </div>
          </div>

          {/* Content — animates on each state change via key */}
          <div key={selectedId ?? "__empty"} className="sidebar-enter" style={{ display: "contents" }}>
            {selectedId === "D001" ? (
              <SidebarActive onDispatch={handleDispatch} dispatched={dispatched} />
            ) : selectedId ? (
              <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "32px 24px", textAlign: "center", gap: "12px" }}>
                <div style={{ width: "56px", height: "56px", borderRadius: "14px", background: "#FEF3C7", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "26px" }}>
                  🔍
                </div>
                <div style={{ fontSize: "14px", fontWeight: 700, color: "#0F172A" }}>
                  Hotspot #{selectedId}
                </div>
                <div style={{ fontSize: "12.5px", color: "#64748B", lineHeight: 1.6 }}>
                  {HOTSPOTS.find((h) => h.id === selectedId)?.label}
                </div>
                <div
                  style={{
                    padding: "6px 12px", background: "#FFFBEB",
                    border: "1px solid #FDE68A", borderRadius: "6px",
                    fontSize: "12px", fontWeight: 600, color: "#92400E",
                  }}
                >
                  Running AI classification...
                </div>
              </div>
            ) : (
              <SidebarEmpty />
            )}
          </div>
        </div>
      </main>

      {/* Screen badge */}
      <ScreenBadge screen={screen} />

      {/* Dispatch toast */}
      <DispatchToast visible={showToast} />
    </div>
  );
}
